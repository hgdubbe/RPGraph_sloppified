# Using Theme Interview

The `theme-interview` folder is the complete skill. It contains Markdown instructions and supporting references, with no application, runtime, scripts, API keys, or vendor-specific tools.

For an agent that supports `SKILL.md` packages, copy the entire folder into its configured skills directory. Directory conventions and automatic discovery depend on the host; follow that agent's own configuration. Keep the relative `references` directory intact.

For any other agent with file access, use:

> Read `theme-interview/SKILL.md` and use it to interview me and create a detailed theme prompt for my target system. Read the linked references when instructed. After delivering the prompt, ask whether to apply it, and if I say yes, implement it with your available tools.

For a chat-only agent, attach the skill and its three reference files with the same instruction. It can conduct the interview and write the prompt; applying a theme requires access to the target and suitable tools.

Examples:

- “Use theme-interview to create a restrained dark theme for this dashboard.”
- “Use theme-interview for my editor. Interview me about the visual direction first.”
- “Use theme-interview for a 16-color terminal theme. Choose the aesthetics; give me the prompt only.”

The workflow produces `theme-brief.md` and `theme-prompt.md`, then offers application unless execution or prompt-only output was already explicitly chosen. Saying yes authorizes the scoped implementation; the agent then applies and checks it rather than merely returning another prompt.

The source analysis is in `theme-interview/references/pattern-analysis.md`. The package was structurally validated for the local skill format. Its plain Markdown workflow is portable, but runtime discovery and execution have not been tested in Claude or Hermes.
