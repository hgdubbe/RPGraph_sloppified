# Standalone theme prompt blueprint

Write a finished, imperative implementation prompt using the relevant sections below. These are authoring instructions, not placeholders to leave in the output. Use Markdown; XML-style boundaries are optional. Scale detail to the target's capabilities, not an arbitrary word count.

## 1. Objective and execution context

Name the theme, target, scope, user task, and desired result. Record inspected stack/schema and known paths, plus unresolved compatibility facts. State what content, behavior, navigation, and existing work must remain intact. Tell the executing agent to inspect the current target and use its native conventions before editing.

Embed no claimed approval. The prompt describes the work; the user's actual request or execution response supplies authorization. Do not restart a completed aesthetic interview when executing; clarify only unresolved material issues.

## 2. Visual thesis

Describe the overall impression and a few governing principles. Explain how those principles control decisions: “calm” might mean low decorative contrast, generous group separation, a clear text hierarchy, and motion limited to state feedback. Name what provides the theme's identity without assuming every theme needs gradients, glow, texture, or dramatic motion.

## 3. Semantic tokens and mappings

Use tables with **token/role, exact value, use, native mapping**. Include only supported categories; explicitly mark meaningful limitations. Define requested modes separately. Verify native keys rather than inventing plausible names.

- **Colors:** canvas, surfaces/elevation, primary/secondary/muted text, borders, action and its foreground, focus, selection, disabled, error/warning/success/info. Separate semantic status from decoration. Add syntax categories, ANSI colors, chart palettes or other target-specific roles when applicable.
- **Typography:** actual font family and fallback, available weights, role sizes, line height, tracking, readable measure, and responsive/native scaling. Say how fonts are supplied; do not assume remote font loading or licenses.
- **Spacing and layout:** base scale, density, control heights, padding/gaps, container rules and breakpoints where supported. Specify exact values or bounded rules rather than “lots of whitespace.”
- **Geometry:** radii by role, border widths/styles, nested corner treatment.
- **Depth/material:** exact shadow layers, opacity, blur, textures, gradients and blend behavior, or an explicit no-effects policy. Define fallback rendering for unsupported effects.
- **Motion:** affected properties, duration, easing, amplitude, triggers, repetition and reduced-motion alternative. No motion is a valid complete choice.

Keep raw palette values separate from semantic roles when helpful. Use exact syntax snippets only where they prevent implementation ambiguity and the target supports them. Do not reproduce utility classes from a different stack.

## 4. Component and state recipes

List actual target components, not a mandatory web component catalog. For each important component define anatomy, hierarchy, spacing, token references, variants and applicable states.

Cover default, hover when available, keyboard focus, pressed/active, selected, disabled, loading, empty, error and success where relevant. Unsupported states are omitted, not fabricated. Explain keyboard/touch equivalents for pointer effects; do not make essential information hover-only. Do not give noninteractive cards misleading action feedback.

For editors include text selection, search, current line, syntax, diagnostics and diffs. For terminals include ANSI normal/bright colors, cursor and selection. A palette-only target may need a thorough mapping table instead of component recipes.

## 5. Composition and adaptation

Describe hierarchy, alignment, grouping, rhythm, navigation and target-specific content organization. Preserve existing structure unless layout changes are within scope. Define small/large viewport transformations only for resizable interfaces that support them; consider zoom and text scaling.

Name what must retain visual identity and what may simplify. Keep essential content accessible, account for long labels and localization, and avoid clipping or accidental horizontal overflow. For fixed-layout targets, specify their actual scaling or size constraints instead.

## 6. Signature details and anti-patterns

Choose a small number of distinctive, feasible details. State their placement, treatment, and fallback. Derive them from the interview; do not impose a universal checklist of visual effects.

Write a few concrete exclusions tied to the selected direction: e.g. avoid decorative gradients in a flat typographic theme, avoid large promotional headings in dense working panels, or avoid colors that confuse selection with errors. Global rules and component exceptions must agree explicitly.

## 7. Accessibility and performance

Set observable checks appropriate to the platform: legible text, distinguishable controls and selection, visible keyboard focus, non-color status cues, usable hit areas, zoom/text scaling and reduced motion. For web targets, typically target WCAG AA text contrast: 4.5:1 normal text and 3:1 qualifying large text, plus applicable 3:1 non-text contrast checks. These are checks to perform, not a blanket compliance claim.

Check actual composited backgrounds, gradients and interaction states. Define target-appropriate touch sizing when relevant, distinguishing product targets from formal standard minima. For unsupported accessibility controls, describe the limitation and best available adaptation.

Bound decorative cost; prefer existing assets and capabilities. Specify static alternatives for expensive or unsupported effects and stop animation that is unwanted or conflicts with reduced-motion preferences.

## 8. Implementation and acceptance

Give a short ordered plan: inspect current state; map tokens; implement native theme/shared styles; adapt scoped components; validate/load; visually inspect when possible; fix scoped regressions; report outputs and limitations.

Include acceptance checks grounded in this particular prompt:

- All required native theme keys and requested modes are valid.
- Named representative surfaces/components use the intended roles and states.
- Signature details are visibly present where supported.
- Functional behavior and user content are preserved.
- Appropriate syntax/build/loading and interaction checks pass.
- Contrast, focus, resizing and motion checks have recorded results or explicit unverified status.

Ask for an execution report with changed files/settings, checks, limitations, and revert guidance. Do not require deployment or publication unless that was explicitly included in scope.

## Author's final consistency pass

Can another agent implement this without the original conversation? Are all referenced tokens defined? Do chosen values obey the global rules? Are native keys verified? Are state foreground/background pairs complete? Are mode and motion fallbacks explicit? Are unknown facts labeled? Does the detail serve the target instead of reproducing an unrelated example?
