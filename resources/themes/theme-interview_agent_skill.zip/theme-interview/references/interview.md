# Interview guide

Use this as a branching question bank, not a form to read in full. Reuse answers from the request and target inspection. Technical questions should go to the user only when they cannot be answered from accessible context.

## Opening: target and purpose

If neither is known, begin with: “What system are we theming, and which parts should change? A project path, app name, or example screen is enough.” Then establish the audience and main task: reading, repeated operational work, analysis, browsing, promotion, creative exploration, or something else.

Useful scope choices: palette/theme configuration only; restyle existing components; redesign named screens; system-wide visual language. Separate theme generation from activation if the target distinguishes them.

For existing products, ask what must remain recognizable or unchanged. For a specific platform, inspect its theme extension points and version before drafting native configuration. For an unspecified future target, produce a portable specification and explicitly defer native mapping.

## Direction: ask about observable differences

- **Mood:** “Should this feel calm and precise, warm and tactile, editorial and expressive, or something else?” Ask for two or three desired qualities and one unwanted quality.
- **References:** “Any examples you like or dislike? Which part: colors, type, layout, depth, or interactions?” Do not infer that liking a screenshot means adopting its entire interface.
- **Intensity:** “Subtle refresh, clearly distinctive, or visually bold?” Connect the answer to actual placement: strong identity in display areas can coexist with restrained working controls.
- **Modes:** light, dark, both, or follow the target's existing mode. For both, ask whether they should be equivalent counterparts or intentionally different moods.
- **Color:** fixed brand colors, preferred hue family, or agent-selected. Separate decorative accents from success/warning/error meaning.
- **Typography:** editorial serif, neutral sans, geometric, monospace, or preserve current fonts. Ask about required scripts/languages and font availability when relevant.
- **Density:** compact for repeated work, balanced, or spacious. Ask which screen must fit the most information; do not impose landing-page spacing on a tool.
- **Geometry/depth:** sharp or rounded; flat, outlined, softly elevated, or tactile. Explain combinations through a button or panel example.
- **Motion:** none, functional transitions, or expressive decoration. Ask only when supported by the target.

Do not ask the user to select hex codes, shadow layers, or exact easing curves unless they want that control. Derive these from their preferences and show the result in the prompt.

## Constraints: branch by target

| Target | Information that materially changes the theme |
| --- | --- |
| Web or application source | Styling mechanism, shared components, routes in scope, devices, keyboard/touch use, existing assets, supported locales |
| Native desktop or mobile UI | Platform resource system, native controls, scaling, system accessibility settings, supported appearance modes |
| Editor or IDE | UI colors versus syntax/semantic tokens, language samples, selections/search/diffs/diagnostics, native theme schema |
| Terminal | Truecolor/256/16-color support, ANSI mapping, normal/bright pairs, cursor, selection, font controlled separately or not |
| Dashboard or data-heavy UI | Table density, selected/hover rows, charts and categorical/ordered colors, non-color status cues |
| Themeable hosted product | Supported settings or import format, limitations, preview/activation capabilities, named destination |
| Other target | Discover supported styling primitives first; apply the same intent-to-token-to-behavior method |

Ask about fixed assets, offline operation, dependency restrictions, accessibility needs, and performance only where those constraints matter. Do not turn optional preferences into blockers.

## Synthesis and stopping point

Maintain this compact brief, without requiring the user to fill it out:

- Target/scope and supported capabilities: inspected facts versus unverified assumptions.
- Audience/task and desired emotional qualities.
- Chosen direction and rejected traits.
- Modes, palette roles, type direction, density, geometry, motion.
- Signature details and where they belong.
- Preserved behavior/content, constraints, and assets.
- Delegated choices and remaining execution prerequisites.

Resolve material contradictions with a concrete recommendation. Example: “For a dense monitoring screen, use the rounded tactile style in panels and primary actions; keep table rows compact and motion static.” If the user wants both corner extremes, allocate them to explicit roles or ask which wins.

A typical interview takes a few short rounds, but there is no quota. A complete initial brief may need only one targeted follow-up. “Surprise me” delegates aesthetics, not an unknown target or unlimited modification scope.

## Example continuation

User: “A warm, restrained dark theme for my editor. No animation. You choose the colors.”

Agent: Identify the editor/version and available theme schema from context; ask only if unknown. Ask whether both syntax colors and application chrome are in scope if not established. Propose warm neutral surfaces, a limited amber accent, and distinct diagnostics; give exact values and verified native mappings in the final prompt. Do not ask about hero sections, mobile menus, hover transforms, or a JavaScript animation library. Deliver the prompt, then offer to create/apply the editor theme.
