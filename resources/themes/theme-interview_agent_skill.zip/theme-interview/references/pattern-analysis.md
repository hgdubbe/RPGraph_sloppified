# Source patterns and design rationale

## Evidence reviewed

The user-supplied `Textdokument (neu).txt` contained three full examples: Linear / Modern, Bauhaus, and High-Fidelity Claymorphism. Additional prompt panels inspected on [Design Prompts](https://www.designprompts.dev/) on 2026-09-17 were Monochrome, Terminal, and Enterprise (whose prompt title was Corporate Trust). These provide contrasting approaches to type, material, geometry, and interaction; they are a sample, not an exhaustive survey.

The website examples reinforce the same role/context wrapper followed by visual principles, token values, component treatment, layout, motion, responsive behavior, and distinctive details. The useful transferable pattern is the progression from intention to implementable rules. The following analysis and skill instructions are original synthesis; full third-party prompts are not bundled.

## What makes a detailed prompt work

| Pattern | Function | Generalization in this skill |
| --- | --- | --- |
| Execution role and context inspection | Connects visual direction to an existing system | Inspect native capabilities and scope before assuming implementation tools |
| Aesthetic thesis and reference imagery | Establishes a coherent decision basis | Ask about desired qualities, then translate them into visual decisions |
| Explicit tokens with usage | Makes choices reproducible | Use exact values, semantic roles, and verified native mappings |
| Component recipes | Shows how global rules combine locally | Cover actual target components and their applicable states |
| Layout and adaptation rules | Preserves identity across conditions | Describe density, hierarchy, scaling and supported modes |
| Signature details | Makes style recognizable beyond a palette swap | Select a few feasible details based on user intent |
| Negative constraints | Prevents drift toward incompatible defaults | Use concrete exclusions, not universal bans borrowed from one style |
| Motion and feedback | Defines behavior as part of appearance | Specify triggers and timing, including a valid static treatment |
| Acceptance checks | Connects specification to observable output | Validate both native integration and visible results where possible |

Detail is useful when it removes ambiguity. Repeating emphatic adjectives or adding effects without placement, values and constraints does not make a prompt more implementable.

## Lessons from the supplied document

- Linear / Modern uses lighting, translucent layering and restrained movement as its identity. Those are aesthetic choices, not a universal prescription for a professional product.
- Bauhaus uses hard edges, primary-color composition and offset shadows. The contrast with the first example demonstrates why radius, shadow and motion rules must be derived from the chosen direction.
- Claymorphism specifies a material model that connects lighting to resting, floating and pressed states. That causal connection is more reusable than its particular palette or font selection.
- All three combine exact values with intended use. This supports consistent implementation better than an adjective-only prompt.

## Corrections rather than literal copying

The supplied clay example declares a minimum radius of 20px while also prescribing 16px icon containers and 8px badges. A generated prompt should either declare role-specific exceptions or choose one consistent system. It should not repeat both as absolute rules.

The source examples mix generic intent with framework utilities, particular libraries and marketing-page sections. Those details are unsuitable as unconditional rules for native apps, terminals, editors, or dense operational screens. Some accessibility assertions also need actual color-pair and state verification. Preserve the reasoning structure while checking the proposed values and capabilities independently.

## Workflow additions requested by the user

The reusable skill adds an adaptive interview, an explicit capability check, a self-contained final prompt, and a post-delivery execution choice. The theme specification remains useful across agents, while application depends honestly on the host's available tools and access. Creating this skill does not itself initiate a theme interview or authorize modifications to an unspecified target.
